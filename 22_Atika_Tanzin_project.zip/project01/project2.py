import random
import string
import tkinter as tk
from tkinter import messagebox

def generate_password():
    try:
        length = int(length_entry.get())
        if length < 4:
            raise ValueError("Password length must be at least 4.")
        
        include_uppercase = uppercase_var.get()
        include_numbers = numbers_var.get()
        include_special = special_var.get()

        characters = string.ascii_lowercase
        if include_uppercase:
            characters += string.ascii_uppercase
        if include_numbers:
            characters += string.digits
        if include_special:
            characters += string.punctuation
        
        if not characters:
            raise ValueError("You must select at least one character type.")

        global password  # Make password accessible to the copy function
        password = ''.join(random.choice(characters) for _ in range(length))
        result_label.config(text=f"Generated Password: {password}")
    except ValueError as e:
        messagebox.showerror("Invalid Input", str(e))

def copy_to_clipboard():
    try:
        if password:
            root.clipboard_clear()
            root.clipboard_append(password)
            root.update()  # Keeps the clipboard content after the program closes
            messagebox.showinfo("Copied", "Password copied to clipboard!")
        else:
            raise ValueError("No password to copy.")
    except Exception:
        messagebox.showerror("Error", "Generate a password first before copying.")

# Create the main window
root = tk.Tk()
root.title("Password Generator")

password = ""  # Initialize a variable to store the generated password

# Input for password length
length_label = tk.Label(root, text="Password Length:")
length_label.grid(row=0, column=0, padx=10, pady=5)

length_entry = tk.Entry(root)
length_entry.grid(row=0, column=1, padx=10, pady=5)

# Checkboxes for password criteria
uppercase_var = tk.BooleanVar()
numbers_var = tk.BooleanVar()
special_var = tk.BooleanVar()

uppercase_checkbox = tk.Checkbutton(root, text="Include Uppercase Letters", variable=uppercase_var)
uppercase_checkbox.grid(row=1, column=0, columnspan=2, pady=5)

numbers_checkbox = tk.Checkbutton(root, text="Include Numbers", variable=numbers_var)
numbers_checkbox.grid(row=2, column=0, columnspan=2, pady=5)

special_checkbox = tk.Checkbutton(root, text="Include Special Characters", variable=special_var)
special_checkbox.grid(row=3, column=0, columnspan=2, pady=5)

# Generate button
generate_button = tk.Button(root, text="Generate Password", command=generate_password)
generate_button.grid(row=4, column=0, columnspan=2, pady=10)

# Copy to clipboard button
copy_button = tk.Button(root, text="Copy to Clipboard", command=copy_to_clipboard)
copy_button.grid(row=5, column=0, columnspan=2, pady=10)

# Label to display the generated password
result_label = tk.Label(root, text="")
result_label.grid(row=6, column=0, columnspan=2, pady=10)

# Run the application
root.mainloop()
